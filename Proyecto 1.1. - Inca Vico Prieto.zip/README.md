# Guía Técnica: Bastionado de la BIOS/UEFI

## Enlace a la Publicación (CodeLab)

Puedes acceder a la guía interactiva publicada en GitHub Pages aquí:

[Guía de Bastionado UEFI](https://incavicoprieto-ui.github.io/cyber-IVP_hardening/Codelab/identificador-unico-del-codelab/)

---
